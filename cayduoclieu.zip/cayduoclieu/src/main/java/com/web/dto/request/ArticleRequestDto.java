package com.web.dto.request;

import lombok.*;

import java.time.LocalDateTime;

@Getter
@Setter
public class ArticleRequestDto {

}
